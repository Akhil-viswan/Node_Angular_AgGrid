import { Component, OnInit } from '@angular/core';
import { GridOptions } from 'ag-grid-community';
import { ServiceService } from './service.service';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})
export class AppComponent implements OnInit {
  title = 'frontEndPro';
  gridApi;
  gridColumnApi;
  bbc_date: any;
 gridOptions: GridOptions;
 arBucketAgingSelectedRows = true;
  columnDefs: any;
  defaultColDef;
  statusBar;
  rowData: any;
  gridParams: any;
 gridResetOn: boolean = true;
 gridAddOn: boolean = true;
 gridSaveOn: boolean = false;
 gridDeleteOn: boolean = false;
 gridSelectedRows:any;

 constructor(private _service: ServiceService,){

 }
 ngOnInit() {
   
  this.gridInit();
  this.getEmpDetails();
}

// initially get data from api
getEmpDetails(){
  let url = "http://localhost:3000/users/show";

  this._service.sendGetRequest(url).subscribe(data =>{
    console.log("LLLL", data);

    this.rowData = data;
    this.gridSaveOn = false;
    this.gridDeleteOn = false;
    this.gridResetOn = false;
  })
}

/**
 * Grid init function
 */

gridInit(){
  this.columnDefs = [
    {headerName: '', field: 'checkSelect', checkboxSelection: true, width: 50 },
    {headerName: 'First Name', field: 'firstName' },
    {headerName: 'Last Name', field: 'lastName' },
    {headerName: 'Age', field: 'age'},
    {headerName: 'Contact', field: 'ph_no'},
    {headerName: 'Designation', field: 'designation'},
    {headerName: 'Gender', field: 'gender',  width: 70},
];

this.defaultColDef = {
  flex: 1,
  resizable: true,
  editable: true
};

this.gridOptions = {
 
};

}

/**
 * grid ready function
 */

onGridReady(params) {
  this.gridOptions.api.sizeColumnsToFit();
  this.gridParams = params;

  this.gridApi = params.api;
  this.gridColumnApi = params.columnApi;
}

/**
 * grid row select function
 */

ongridRowSelected(event: any) {
  this.gridSelectedRows = this.gridOptions.api.getSelectedRows();
  // var isId = this.gridSelectedRows.find(elm => {
  //   return !elm.id
  // });

  if(this.gridSelectedRows.length>0){
    this.gridDeleteOn = true;
  } 
  else{
    this.gridDeleteOn = false;
  }

  if(this.gridSelectedRows.length>0 && this.gridSelectedRows.length<2){
    this.gridSaveOn = true;
  } 
  else{
    this.gridSaveOn = false;
  } 


  // this.columnDefs[0].cellStyle = (param)=>{
  //   return  {'pointer-events': 'none', opacity: '0.4' }
  // };
}


/**
 * Add function for grid
 */

addNewRow() {
  const newItem = this.newRowData();
  this.gridApi.updateRowData({ add: [newItem], addIndex: 0 });
  this.gridOptions.api.forEachNode(node => node.rowIndex ? 0 : node.setSelected(true));

  this.gridOptions.api.setFocusedCell(0, "description");
  this.gridOptions.api.startEditingCell({
    rowIndex: 0,
    colKey: 'description'
});
  this.gridSaveOn = true;
  this.gridAddOn = false;
}

  	// New Row Data
    newRowData(): any {
	
      const newRow = {
        firstName: '',
        lastName: '',    
        age: '',	
        ph_no: '',
        designation : '',
        gender: '',
      };
      return newRow;
    }

/**
 * save function for grid
 */

saveGrid(){
  this.gridApi.clearFocusedCell();
  this.gridSelectedRows = this.gridOptions.api.getSelectedRows();
  console.log(this.gridSelectedRows);
  let model = this.gridSelectedRows[0];


  if(model.gender == "m" || model.gender == "f"){
  
  
  if(!model.id){
    let url = "http://localhost:3000/users/add";

    this._service.sendPostRequest(url, model).subscribe(data =>{
      console.log("LLLL", data);
      alert("Successfully added");
      this.getEmpDetails();
    })
  }

  else{
    let id = model.id
    let url = `http://localhost:3000/users/update/${id}`;

    this._service.sendPutRequest(url, model).subscribe(data =>{
      console.log("LLLL", data);
      alert("Successfully updated");
      this.getEmpDetails();
    })
  }
  }
  else{
    alert("Gender should be either 'f' or 'm'");
    this.getEmpDetails();
    
  }

}

/**
 * cancel function for grid
 */

cancelData(){
  this.getEmpDetails();
  this.gridResetOn = false;
  this.gridSaveOn = false;
  this.gridAddOn = true;
}

/**
 * delete function for grid
 */

deleteGrid(){
  
  this.gridSelectedRows = this.gridOptions.api.getSelectedRows();
  let id = this.gridSelectedRows[0].id
  let url = `http://localhost:3000/users/delete/${id}`;

  this._service.sendDeleteRequest(url).subscribe(data =>{
    console.log("LLLL", data);
    alert("Successfully Deleted");
    this.getEmpDetails();
    this.gridDeleteOn = false;
  })
}

}
