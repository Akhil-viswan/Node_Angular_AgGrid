import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class ServiceService {
  constructor(private httpClient: HttpClient) { }

  public sendGetRequest(url){
    return this.httpClient.get(url);
  }

  public sendPostRequest(url, model){
    return this.httpClient.post(url, model);
  }

  public sendPutRequest(url, model){
    return this.httpClient.put(url, model);
  }
  public sendDeleteRequest(url){
    return this.httpClient.delete(url);
  }
}
